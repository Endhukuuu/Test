<?php
// Autoload and bootstrap
require_once __DIR__ . '/vendor/autoload.php';
echo "Running PHP Service with symfony/http-foundation 5.2.0\n";
