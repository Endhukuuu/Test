"""
Python Service using urllib3
"""
import sys

def execute():
    print("Service running with urllib3 1.24.1")
    return True

if __name__ == '__main__':
    execute()
