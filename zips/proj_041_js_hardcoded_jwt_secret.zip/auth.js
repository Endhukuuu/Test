const JWT_SECRET = "production_super_jwt_secret_token_123456789";
module.exports = { JWT_SECRET };
