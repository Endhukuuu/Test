# proj_041_js_hardcoded_jwt_secret
Security vulnerability test suite.
