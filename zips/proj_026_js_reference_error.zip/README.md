# proj_026_js_reference_error
Module illustrating Call to non-existent symbol.
