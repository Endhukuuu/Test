document.addEventListener("DOMContentLoaded", () => {
    initializeThemeEngine();
});
