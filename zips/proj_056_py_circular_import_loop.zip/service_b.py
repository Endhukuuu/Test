import service_a
def do_b(): return service_a.do_a()
