import service_b
def do_a(): return service_b.do_b()
