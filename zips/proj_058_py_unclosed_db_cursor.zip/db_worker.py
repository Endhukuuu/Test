def get_cursor(conn):
    cur = conn.cursor()
    cur.execute("SELECT 1")
    # missing cur.close()
