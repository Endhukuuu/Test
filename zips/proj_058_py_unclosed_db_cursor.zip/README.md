# proj_058_py_unclosed_db_cursor
Architecture flaw test suite: Database connection connection leak.
