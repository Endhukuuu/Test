# proj_062_js_event_emitter_leak
Architecture flaw test suite: MaxListenersExceededWarning unbounded listeners.
