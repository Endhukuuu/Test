const EventEmitter = require("events");
const bus = new EventEmitter();
for (let i = 0; i < 50; i++) bus.on("data", () => {});
