"""
Python Service using pyyaml
"""
import sys

def execute():
    print("Service running with pyyaml 5.3.1")
    return True

if __name__ == '__main__':
    execute()
