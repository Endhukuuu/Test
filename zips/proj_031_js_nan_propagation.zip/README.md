# proj_031_js_nan_propagation
Module illustrating Arithmetic operations yielding NaN unchecked.
