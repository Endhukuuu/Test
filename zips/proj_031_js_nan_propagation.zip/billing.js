function calcTax(val) {
    return val * undefined;
}
module.exports = { calcTax };
