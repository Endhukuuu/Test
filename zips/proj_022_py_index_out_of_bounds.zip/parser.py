def get_header(tokens):
    return tokens[3]
