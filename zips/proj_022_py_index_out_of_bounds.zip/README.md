# proj_022_py_index_out_of_bounds
Module illustrating Unchecked array index access.
