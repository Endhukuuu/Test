# proj_047_py_insecure_deserialization
Security vulnerability test suite.
