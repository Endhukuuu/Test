function computeFact(n) {
    return n * computeFact(n - 1);
}
module.exports = { computeFact };
