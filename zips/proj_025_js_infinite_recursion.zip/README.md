# proj_025_js_infinite_recursion
Module illustrating Missing base condition in recursion.
