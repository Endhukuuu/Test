function displayMsg(user, text) {
    document.getElementById("chatBox").innerHTML += "<div>" + user + ": " + text + "</div>";
}
