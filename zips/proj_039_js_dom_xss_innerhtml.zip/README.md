# proj_039_js_dom_xss_innerhtml
Security vulnerability test suite.
