<?php
function exportCsv($rows) {
    $fp = fopen("output.csv", "w");
    foreach($rows as $r) fputcsv($fp, $r);
    // missing fclose($fp)
}
