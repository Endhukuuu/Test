# proj_063_php_unclosed_stream_resource
Architecture flaw test suite: File descriptor leak via fopen without fclose.
