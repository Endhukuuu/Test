def format_price(p, flag=False):
    if flag:
        res_val = f"${p:.2f}"
    return res_val
