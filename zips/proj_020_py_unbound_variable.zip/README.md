# proj_020_py_unbound_variable
Module illustrating Local variable referenced before assignment.
