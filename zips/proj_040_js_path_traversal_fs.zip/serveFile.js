const fs = require("fs");
const path = require("path");
function serve(req, res) {
    const p = path.join("/public", req.url);
    return fs.readFileSync(p);
}
