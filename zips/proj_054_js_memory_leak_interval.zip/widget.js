function initTracker() {
    setInterval(() => { console.log("ping"); }, 500);
}
