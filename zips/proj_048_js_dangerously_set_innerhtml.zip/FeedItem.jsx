export function FeedItem({ content }) {
    return <div dangerouslySetInnerHTML={{ __html: content }} />;
}
