# proj_048_js_dangerously_set_innerhtml
Security vulnerability test suite.
