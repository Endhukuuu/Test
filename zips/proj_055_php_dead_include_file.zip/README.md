# proj_055_php_dead_include_file
Architecture flaw test suite: require_once pointing to missing script.
