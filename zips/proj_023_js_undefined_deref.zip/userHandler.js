function getCity(user) {
    return user.profile.address.city;
}
module.exports = { getCity };
