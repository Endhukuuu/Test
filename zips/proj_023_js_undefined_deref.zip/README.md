# proj_023_js_undefined_deref
Module illustrating Cannot read property of undefined.
