# proj_034_js_array_map_nonfunc
Module illustrating Passing non-function to Array.prototype.map.
