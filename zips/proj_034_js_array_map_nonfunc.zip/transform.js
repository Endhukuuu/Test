function mapItems(arr, fn) {
    return arr.map(fn);
}
mapItems([1, 2, 3], null);
