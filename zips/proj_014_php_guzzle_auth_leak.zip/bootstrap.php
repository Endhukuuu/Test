<?php
// Autoload and bootstrap
require_once __DIR__ . '/vendor/autoload.php';
echo "Running PHP Service with guzzlehttp/guzzle 6.3.0\n";
