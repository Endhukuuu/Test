"""
Python Service using flask
"""
import sys

def execute():
    print("Service running with flask 2.0.1")
    return True

if __name__ == '__main__':
    execute()
