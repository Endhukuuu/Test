<?php
function verifyOrder($order) {
    return $order->getStatus();
}
