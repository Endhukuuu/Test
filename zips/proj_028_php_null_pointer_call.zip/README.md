# proj_028_php_null_pointer_call
Module illustrating Method call on null object.
