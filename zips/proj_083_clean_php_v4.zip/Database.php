<?php
declare(strict_types=1);

class SafeDatabaseWrapper {
    private PDO $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    public function queryById(int $id): ?array {
        $stmt = $this->pdo->prepare('SELECT id, name FROM users WHERE id = :id LIMIT 1');
        $stmt->execute(['id' => $id]);
        $res = $stmt->fetch(PDO::FETCH_ASSOC);
        return $res ?: null;
    }
}
