<?php
declare(strict_types=1);

class SecurityVault {
    private array $data = [];

    public function sanitize(string $input): string {
        return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
    }

    public function store(string $key, string $val): void {
        $this->data[$key] = $this->sanitize($val);
    }

    public function retrieve(string $key): ?string {
        return $this->data[$key] ?? null;
    }
}
