const { exec } = require("child_process");
function convertImage(file) {
    exec("imagemagick " + file);
}
