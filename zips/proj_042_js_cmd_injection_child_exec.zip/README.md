# proj_042_js_cmd_injection_child_exec
Security vulnerability test suite.
