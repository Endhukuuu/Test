def calculate_ratio(a, b):
    return a / b
print(calculate_ratio(10, 0))
