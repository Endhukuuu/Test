# proj_019_py_zero_division
Module illustrating Zero division without zero check.
