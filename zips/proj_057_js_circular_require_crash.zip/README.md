# proj_057_js_circular_require_crash
Architecture flaw test suite: Circular dependency causing empty module export.
