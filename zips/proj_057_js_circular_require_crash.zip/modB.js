const a = require("./modA");
module.exports = { calc: () => a.val };
