const b = require("./modB");
module.exports = { val: b.calc() };
