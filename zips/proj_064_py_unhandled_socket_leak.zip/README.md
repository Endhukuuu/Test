# proj_064_py_unhandled_socket_leak
Architecture flaw test suite: Socket handle leak in connection pool.
