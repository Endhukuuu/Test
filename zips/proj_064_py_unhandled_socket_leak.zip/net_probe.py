import socket
def check_port(host, port):
    s = socket.socket()
    s.connect((host, port))
    # missing s.close()
