document.addEventListener('DOMContentLoaded', () => {
    const out = document.getElementById('output');
    if (!out) return;
    const msg = document.createElement('p');
    msg.textContent = 'Application initialized securely.';
    out.appendChild(msg);
});
