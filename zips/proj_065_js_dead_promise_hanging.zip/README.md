# proj_065_js_dead_promise_hanging
Architecture flaw test suite: Promise constructor never calling resolve or reject.
