function acquireLock() {
    return new Promise((resolve, reject) => {
        // hanging promise - never resolves
    });
}
module.exports = { acquireLock };
