const { acquireLock } = require("./syncLock");
