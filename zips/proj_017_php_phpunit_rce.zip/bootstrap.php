<?php
// Autoload and bootstrap
require_once __DIR__ . '/vendor/autoload.php';
echo "Running PHP Service with phpunit/phpunit 7.5.0\n";
