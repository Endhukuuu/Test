# proj_029_php_array_key_undefined
Module illustrating Direct access to undefined array key.
