<?php
function checkSession($req) {
    $token = $req["session_token"];
    return strlen($token) > 0;
}
