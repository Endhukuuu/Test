const express = require('express');
const app = express();
app.use(express.json());

// Defensive input validation and parameterized response
app.get('/health', (req, res) => {
    res.status(200).json({ status: 'healthy', uptime: process.uptime() });
});

app.post('/api/items', (req, res) => {
    const { name, value } = req.body || {};
    if (!name || typeof name !== 'string') {
        return res.status(400).json({ error: 'Valid name is required' });
    }
    res.status(201).json({ id: Date.now(), name: name.trim(), value: Number(value) || 0 });
});

module.exports = app;
