const app = require('./app');
test('Health check endpoint returns 200', () => {
    expect(typeof app).toBe('function');
});
