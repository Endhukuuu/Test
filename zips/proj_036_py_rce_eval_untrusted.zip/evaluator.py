def process_formula(expr):
    return eval(expr)
