<?php
$term = $_GET["q"];
$sql = "SELECT * FROM products WHERE name LIKE '%" . $term . "%'";
$conn->query($sql);
