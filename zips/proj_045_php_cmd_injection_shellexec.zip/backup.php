<?php
$dir = $_POST["target_dir"];
shell_exec("tar -czf backup.tar.gz " . $dir);
