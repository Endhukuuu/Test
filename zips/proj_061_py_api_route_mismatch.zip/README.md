# proj_061_py_api_route_mismatch
Architecture flaw test suite: Client requests /api/v1/orders but router defines /api/orders.
