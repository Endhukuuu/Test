import requests
def fetch_orders():
    return requests.get("http://localhost:5000/api/v1/orders")
