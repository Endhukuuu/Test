from flask import Flask
app = Flask(__name__)
@app.route("/api/orders")
def orders(): return []
