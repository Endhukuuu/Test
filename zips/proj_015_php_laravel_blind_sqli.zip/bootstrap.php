<?php
// Autoload and bootstrap
require_once __DIR__ . '/vendor/autoload.php';
echo "Running PHP Service with laravel/framework 8.40.0\n";
