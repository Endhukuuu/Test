def sum_items(lst):
    total = 0
    for x in lst:
        total += x["cost"]
    return total
