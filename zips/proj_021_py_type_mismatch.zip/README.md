# proj_021_py_type_mismatch
Module illustrating String concatenation with integer.
