# proj_049_php_file_inclusion_lfi
Security vulnerability test suite.
