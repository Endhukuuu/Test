const { authGuard } = require("./middleware/authGuard");
authGuard();
