# proj_052_js_dead_require_path
Architecture flaw test suite: Missing require of deleted file.
