# proj_030_py_syntax_unclosed_string
Module illustrating SyntaxError unclosed string literal.
