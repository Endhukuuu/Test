APP_NAME = "Intelligent Service Platform
PORT = 8080
