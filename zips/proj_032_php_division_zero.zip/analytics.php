<?php
function calcRate($clicks, $views) {
    return $clicks / $views;
}
