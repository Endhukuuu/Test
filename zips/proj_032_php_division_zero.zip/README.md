# proj_032_php_division_zero
Module illustrating PHP division by zero without guard.
