"""
Python Service using requests
"""
import sys

def execute():
    print("Service running with requests 2.19.0")
    return True

if __name__ == '__main__':
    execute()
