# proj_038_py_hardcoded_aws_key
Security vulnerability test suite.
