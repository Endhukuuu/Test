# proj_059_js_missing_export_symbol
Architecture flaw test suite: Importing symbol not exported by target file.
