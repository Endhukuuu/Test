const { sendMail } = require("./mailer");
sendMail("user@example.com");
