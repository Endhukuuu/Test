function dispatch(msg) { return true; }
module.exports = { dispatch };
