from main import repo

def create_item_service(item_id: int, title: str, score: float):
    if not title or score < 0:
        raise ValueError("Invalid title or negative score")
    return repo.add(item_id, title, score)
