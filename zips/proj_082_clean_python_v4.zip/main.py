from typing import Optional, List
import copy

class ItemRepository:
    def __init__(self):
        self._db = {}

    def add(self, item_id: int, title: str, score: float) -> dict:
        record = {"id": item_id, "title": title.strip(), "score": float(score)}
        self._db[item_id] = record
        return copy.deepcopy(record)

    def get(self, item_id: int) -> Optional[dict]:
        rec = self._db.get(item_id)
        return copy.deepcopy(rec) if rec else None

repo = ItemRepository()
