# proj_050_py_hardcoded_private_key
Security vulnerability test suite.
