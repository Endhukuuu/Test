# proj_051_py_dead_import_module
Architecture flaw test suite: Dead cross-file import of nonexistent module.
