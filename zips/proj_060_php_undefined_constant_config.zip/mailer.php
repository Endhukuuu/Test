<?php
function send() {
    return mail("a@b.com", "Subj", "Msg", "From: " . SMTP_SENDER);
}
