# proj_060_php_undefined_constant_config
Architecture flaw test suite: Use of undefined global configuration constant.
