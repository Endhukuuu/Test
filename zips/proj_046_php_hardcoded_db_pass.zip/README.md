# proj_046_php_hardcoded_db_pass
Security vulnerability test suite.
