def get_user(db, uid):
    query = "SELECT * FROM users WHERE id = " + str(uid)
    return db.execute(query)
