# proj_035_py_sql_injection_concat
Security vulnerability test suite.
