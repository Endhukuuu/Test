# proj_024_js_unhandled_promise
Module illustrating Async promise rejection without catch.
