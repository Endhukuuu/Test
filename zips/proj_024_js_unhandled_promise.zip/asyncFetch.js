const fs = require("fs").promises;
function writeAudit(data) {
    fs.writeFile("/protected/log.txt", data);
}
module.exports = { writeAudit };
