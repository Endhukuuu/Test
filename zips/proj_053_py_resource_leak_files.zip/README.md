# proj_053_py_resource_leak_files
Architecture flaw test suite: Resource leak unclosed file handles in loop.
