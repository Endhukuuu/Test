def dump_logs(records):
    for r in records:
        f = open(f"log_{r}.txt", "w")
        f.write(str(r))
