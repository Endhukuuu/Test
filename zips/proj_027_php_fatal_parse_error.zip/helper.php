<?php
function logEvent($ev) {
    error_log("Event: " . $ev;
}
