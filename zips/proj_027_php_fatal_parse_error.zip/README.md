# proj_027_php_fatal_parse_error
Module illustrating Unmatched parenthesis in helper function.
