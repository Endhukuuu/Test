# proj_033_py_key_error_dict
Module illustrating KeyError in nested dictionary access.
