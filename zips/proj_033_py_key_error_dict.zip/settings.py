def load_db(conf):
    return conf["database"]["host"]
