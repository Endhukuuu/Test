"""
Python Service using django
"""
import sys

def execute():
    print("Service running with django 3.1.2")
    return True

if __name__ == '__main__':
    execute()
